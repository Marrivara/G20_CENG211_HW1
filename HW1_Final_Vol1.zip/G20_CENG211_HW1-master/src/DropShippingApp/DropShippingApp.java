package DropShippingApp;
/*
* Change SalesDate type from String to Date
* Write Comments
* Delete toString methods
*
* */

import BusinessLayer.DropShippingAppInitializer;
import FileIO.FileReader;

public class DropShippingApp {
    public static void main(String[] args) {
        DropShippingAppInitializer appInitializer = new DropShippingAppInitializer();
        appInitializer.initializeTheApp();
    }
}