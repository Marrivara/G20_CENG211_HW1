package BusinessLayer;

public class Supplier {
    private Product[] products;
    
    public Supplier(Product[] products) {
        this.products = products;
    }
    
    // Copy Constructor
    public Supplier(Supplier supplier) {
    	products = supplier.products;
    }
    
    public Product[] getProducts() {
        return products;
    }


}
